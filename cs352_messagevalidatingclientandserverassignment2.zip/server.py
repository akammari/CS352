import sys
import socket
import hashlib


def read_keys(key_file: str) -> list:
    Keys = []
    with open(key_file, 'r') as key_file:
        for key in key_file:
            Keys.append(key.strip())

    return Keys


def server(port: int, key_file_path: str):
    keys = read_keys(key_file_path)

    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(('0.0.0.0', port))
    server_socket.listen()

    (client_socket, _) = server_socket.accept()

    client_data = client_socket.makefile('r', encoding='ascii', newline='')
    response = client_data.readline()
    print(response)

    if response != 'HELLO\n':
        client_data.close()
        client_socket.close()
        print("Invalid responses from Client")

    client_socket.sendall('260 OK\n'.encode(encoding='ascii'))
    print('260 OK\n'.encode(encoding='ascii'))

    counter = 0
    while True:
        response = client_data.readline()
        print(response)

        if response == "DATA\n":
            hash = hashlib.sha256()
            while True:
                response = client_data.readline()
                print(response)

                if response in ('.\n', '.\n', '.'):
                    break
                escaped_messages = []
                i = 0
                while i < len(response):
                    if response[i] == '\\':
                        i += 1
                    escaped_messages.append(response[i])
                    i += 1
                escape = ''.join(escaped_messages)
                if escape[-1] == '\n':
                    escape = escape[:-1]
                hash.update(escape.encode(encoding='ascii'))
            hash.update(keys[counter].encode(encoding='ascii'))

            client_socket.sendall('270 SIG\n'.encode(encoding='ascii'))
            print('270 SIG\n'.encode(encoding='ascii'))

            client_socket.sendall(
                (hash.hexdigest()+"\n").encode(encoding='ascii'))
            print((hash.hexdigest()+"\n").encode(encoding='ascii'))

            response = client_data.readline()
            print("Test result:", response)

            if response not in ('PASS\n', 'FAIL\n'):
                client_data.close()
                client_socket.close()
                print("Invalid responses from Client")

            client_socket.sendall('260 OK\n'.encode(encoding='ascii'))

            counter += 1

        elif response == "QUIT\n":
            client_data.close()
            client_socket.close()
            break
        else:
            client_data.close()
            client_socket.close()
            print("Invalid responses from Client")


def main():
    if len(sys.argv) != 3:
        print("Usage: python3 server.py <port> <key_file>")
        return

    listen_port = int(sys.argv[1])
    key_file = sys.argv[2]

    server(listen_port, key_file)


if __name__ == '__main__':
    main()
