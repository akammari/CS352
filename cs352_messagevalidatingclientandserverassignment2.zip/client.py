import sys
import socket


def read_messages(message_filename):
    custom_messages = []

    with open(message_filename, 'r') as message_file:
        while True:
            m = message_file.readline()
            if len(m) <= 0:
                break
            message_length = int(m)

            message = message_file.read(message_length).replace(
                "\\", "\\\\").replace(".", "\.")
            if message[-1] != '\n':
                message += '\n'
            message += ".\n"
            custom_messages.append(message.encode(encoding='ascii'))

    return custom_messages


def read_signatures(signature_filename):
    custom_signatures = []

    with open(signature_filename, 'r') as signature_file:
        while True:
            custom_signature = signature_file.readline()
            if len(custom_signature) <= 0:
                break
            custom_signatures.append(custom_signature)

    return custom_signatures


def client(server_name, server_port, custom_messages, custom_signatures):
    custom_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    custom_socket.settimeout(10)
    custom_socket.connect((server_name, server_port))

    custom_socket.sendall('HELLO\n'.encode(encoding='ascii'))
    print('HELLO\n'.encode(encoding='ascii'))

    custom_data = custom_socket.makefile('r', encoding='ascii', newline='')
    response = custom_data.readline()
    print(response)

    if response != '260 OK\n':
        custom_data.close()
        custom_socket.close()
        print("Server response is Invalid")

    counter = 0

    for custom_message in custom_messages:
        custom_socket.sendall('DATA\n'.encode(encoding='ascii'))
        print('DATA\n'.encode(encoding='ascii'))

        custom_socket.sendall(custom_message)
        print(custom_message)

        response = custom_data.readline()
        print(response)

        if response != '270 SIG\n':
            custom_data.close()
            custom_socket.close()
            print("Server response is Invalid")

        response = custom_data.readline()
        print(response)

        if response.strip() == custom_signatures[counter].strip():
            custom_socket.sendall('PASS\n'.encode(encoding='ascii'))
            print("PASS")
            print('PASS\n'.encode(encoding='ascii'))
        else:
            custom_socket.sendall('FAIL\n'.encode(encoding='ascii'))
            print("FAIL")
            print('FAIL\n'.encode(encoding='ascii'))

        response = custom_data.readline()
        print(response)

        if response != '260 OK\n':
            custom_data.close()
            custom_socket.close()
            print("Server response is Invalid")

        counter += 1

    custom_socket.sendall('QUIT\n'.encode(encoding='ascii'))
    print('QUIT\n'.encode(encoding='ascii'))

    custom_data.close()
    custom_socket.close()


def main():
    if len(sys.argv) != 5:
        print("Usage: python3 client.py <server_name> <server_port> <message_filename> <signature_filename>")
        return

    server_name = sys.argv[1]
    server_port = int(sys.argv[2])
    message_filename = sys.argv[3]
    signature_filename = sys.argv[4]

    messages = read_messages(message_filename)
    signatures = read_signatures(signature_filename)

    client(server_name, server_port, messages, signatures)


if __name__ == '__main__':
    main()
